#!/usr/bin/env node
"use strict";

const { runTextIntegrityAutoFix } = require("./text-integrity");

const result = runTextIntegrityAutoFix(process.cwd());

if (result.changed.length) {
  console.log("[fix:text] Arquivos reparados com sucesso:\n");
  for (const entry of result.changed) {
    console.log(`- ${entry.filePath}: ${entry.before} -> ${entry.after} linha(s) suspeita(s)`);
  }
  console.log("");
}

if (result.failures.length) {
  console.error("[fix:text] Alguns arquivos ainda precisam de revisao manual:\n");
  for (const failure of result.failures) {
    console.error(`- ${failure.filePath}: ${failure.reason}`);
  }
  process.exit(1);
}

if (!result.changed.length) {
  console.log("[fix:text] Nenhum arquivo precisou de reparo.");
}
