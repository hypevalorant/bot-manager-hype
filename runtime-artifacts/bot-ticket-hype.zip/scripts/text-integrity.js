"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const DEFAULT_TARGET_DIRS = ["src", "scripts"];
const DEFAULT_TARGET_FILES = ["package.json", "README.md", ".env.example", ".editorconfig", ".gitattributes"];
const DEFAULT_EXTENSIONS = new Set([".js", ".json", ".md", ".env", ".txt", ".yml", ".yaml"]);
const DEFAULT_EXCLUDED_DIRS = new Set([
  "node_modules",
  ".git",
  "assets",
  "data",
  "transcripts",
  "deploy",
  "_recovery_backups",
  "backup",
]);

const utf8Decoder = new TextDecoder("utf-8", { fatal: true });
const WINDOWS_1252_CODE_POINT_TO_BYTE = new Map([
  [0x20ac, 0x80],
  [0x201a, 0x82],
  [0x0192, 0x83],
  [0x201e, 0x84],
  [0x2026, 0x85],
  [0x2020, 0x86],
  [0x2021, 0x87],
  [0x02c6, 0x88],
  [0x2030, 0x89],
  [0x0160, 0x8a],
  [0x2039, 0x8b],
  [0x0152, 0x8c],
  [0x017d, 0x8e],
  [0x2018, 0x91],
  [0x2019, 0x92],
  [0x201c, 0x93],
  [0x201d, 0x94],
  [0x2022, 0x95],
  [0x2013, 0x96],
  [0x2014, 0x97],
  [0x02dc, 0x98],
  [0x2122, 0x99],
  [0x0161, 0x9a],
  [0x203a, 0x9b],
  [0x0153, 0x9c],
  [0x017e, 0x9e],
  [0x0178, 0x9f],
]);

const RESIDUAL_UTF8_PAIR_REPLACEMENTS = new Map([
  ["\u00C3\u00A1", "á"],
  ["\u00C3\u00A2", "â"],
  ["\u00C3\u00A3", "ã"],
  ["\u00C3\u00A4", "ä"],
  ["\u00C3\u00AA", "ê"],
  ["\u00C3\u00A9", "é"],
  ["\u00C3\u00A8", "è"],
  ["\u00C3\u00AD", "í"],
  ["\u00C3\u00B3", "ó"],
  ["\u00C3\u00B4", "ô"],
  ["\u00C3\u00B5", "õ"],
  ["\u00C3\u00B6", "ö"],
  ["\u00C3\u00BA", "ú"],
  ["\u00C3\u00A7", "ç"],
  ["\u00C3\u0089", "É"],
  ["\u00C3\u0081", "Á"],
  ["\u00C3\u0082", "\u00C2"],
  ["\u00C3\u0083", "Ã"],
  ["\u00C3\u0087", "Ç"],
  ["\u00C3\u008A", "Ê"],
  ["\u00C3\u0093", "Ó"],
  ["\u00C3\u0094", "Ô"],
  ["\u00C3\u0095", "Õ"],
  ["\u00C3\u009A", "Ú"],
  ["\u00C2\u00BA", "º"],
  ["\u00C2\u00AA", "ª"],
  ["\u00C2\u00B0", "°"],
  ["\u00C2\u00A7", "§"],
  ["\u00C2\u00A2", "¢"],
  ["\u00C2\u00A3", "£"],
  ["\u00C2\u00A9", "©"],
  ["\u00C2\u00AE", "®"],
  ["\u00C2\u00B9", "¹"],
  ["\u00C2\u00B2", "²"],
  ["\u00C2\u00B3", "³"],
  ["\u00C2\u00BC", "¼"],
  ["\u00C2\u00BD", "½"],
  ["\u00C2\u00BE", "¾"],
  ["\u00C2\u00AB", "«"],
  ["\u00C2\u00BB", "»"],
  ["\u00C2\u00B7", "·"],
  ["\u00C2\u2026", "…"],
  ["\u00C2\u2013", "–"],
  ["\u00C2\u2014", "—"],
  ["\u00C2\u2018", "‘"],
  ["\u00C2\u2019", "’"],
  ["\u00C2\u201C", "“"],
  ["\u00C2\u201D", "”"],
  ["\u00C2\u2022", "•"],
  ["\u00C2\u00B4", "´"],
  ["\u00C2\u00A8", "¨"],
  ["\u00C2\u00A0", " "],
]);

const KNOWN_MOJIBAKE_REPLACEMENTS = new Map([
  ["N\u00C3\u2019O", "N\u00C3O"],
  ["N\u00C3\u0192O", "N\u00C3O"],
  ["N\u00C3\u0192\u00E2\u20AC\u2122O", "N\u00C3O"],
  ["N\u00C3\u0192\u00C6\u2019O", "N\u00C3O"],
  ["PADR\u00C3\u2019O", "PADR\u00C3O"],
  ["PADR\u00C3\u0192\u00E2\u20AC\u2122O", "PADR\u00C3O"],
]);

const ESCAPED_MOJIBAKE_REPLACEMENTS = new Map([
  ["\\u00e2\u008F\u00AD\u00EF\u00B8\u008F", "\\u23ED\\uFE0F"],
  ["\\u00e2\u017E\u2022", "\\u2795"],
  ["\\u00e2\u017E\u2013", "\\u2796"],
  ["\\u00e2\u008F\u00AF\u00EF\u00B8\u008F", "\\u23EF\\uFE0F"],
  ["\\u00e2\u0161\u2122\u00EF\u00B8\u008F", "\\u2699\\uFE0F"],
  ["\\u00e2\u009D\u201C", "\\u2753"],
  ["\\u00e2\u00AD\u0090", "\\u2B50"],
  ["\\u00e2\u00AC\u2026\u00EF\u00B8\u008F", "\\u2B05\\uFE0F"],
  ["\\u00e2\u0153\u2026", "\\u2705"],
  ["\\u00e2\u009D\u0152", "\\u274C"],
  ["\\u00e2\u017E\u00A1\u00EF\u00B8\u008F", "\\u27A1\\uFE0F"],
  ["\\u00e2\u2014\u00BD\u00EF\u00B8\u008F", "\\u25FD\\uFE0F"],
  ["\\u00e2\u2013\u00AB\u00EF\u00B8\u008F", "\\u25AB\\uFE0F"],
  ["\\u00e2\u0153\u008F\u00EF\u00B8\u008F", "\\u270F\\uFE0F"],
  ["\\u00e2\u2122\u00BB\u00EF\u00B8\u008F", "\\u267B\\uFE0F"],
]);

const MOJIBAKE_REGEX =
  /(?:\u00C3(?:[\u0080-\u00BF]|\u0192|\u0160|\u0161|\u2020|\u2021|\u2018|\u2019|\u201C|\u201D|\u2026)|\u00C2[\u0080-\uFFFF]|\u00E2(?:[\u0080-\u00BF]|\u00A2|\u201A|\u201C|\u201D|\u2020|\u2021|\u2026|\u20AC|\u2122|\u0160|\u0161|\u017E)|\u00F0[\u0080-\uFFFF]{1,3}|\uFFFD)/u;
const MOJIBAKE_GLOBAL_REGEX = new RegExp(MOJIBAKE_REGEX.source, "gu");
const LIKELY_MOJIBAKE_CHUNK_REGEX =
  /(?:\u00C3(?:[\u0080-\u00BF]|\u0192|\u0160|\u0161|\u2020|\u2021|\u2018|\u2019|\u201C|\u201D|\u2026)|\u00C2[\u0080-\uFFFF]|\u00E2(?:[\u0080-\u00BF]|\u00A2|\u201A|\u201C|\u201D|\u2020|\u2021|\u2026|\u20AC|\u2122|\u0160|\u0161|\u017E)|\u00F0[\u0080-\uFFFF]{1,3})/u;

function getDefaultConfig(rootDir = process.cwd()) {
  return {
    rootDir,
    targetDirs: [...DEFAULT_TARGET_DIRS],
    targetFiles: [...DEFAULT_TARGET_FILES],
    extensions: new Set(DEFAULT_EXTENSIONS),
    excludedDirs: new Set(DEFAULT_EXCLUDED_DIRS),
  };
}

function normalizeRelativePath(relativePath = "") {
  return String(relativePath || "").replace(/\\/g, "/");
}

function isExcludedPath(relativePath = "", config = getDefaultConfig()) {
  const normalized = normalizeRelativePath(relativePath);
  if (!normalized) {
    return false;
  }

  return normalized.split("/").some((segment) => config.excludedDirs.has(segment));
}

function collectFiles(rootDir, currentDir, config, output) {
  if (!fs.existsSync(currentDir)) {
    return;
  }

  const entries = fs.readdirSync(currentDir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(currentDir, entry.name);
    const relativePath = path.relative(rootDir, fullPath);
    if (isExcludedPath(relativePath, config)) {
      continue;
    }

    if (entry.isDirectory()) {
      collectFiles(rootDir, fullPath, config, output);
      continue;
    }

    const extension = path.extname(entry.name).toLowerCase();
    if (config.extensions.has(extension) || entry.name === ".env") {
      output.push(fullPath);
    }
  }
}

function buildTargetFileList(rootDir = process.cwd(), overrides = {}) {
  const config = {
    ...getDefaultConfig(rootDir),
    ...overrides,
  };

  const files = [];
  for (const relativeDir of config.targetDirs) {
    collectFiles(rootDir, path.join(rootDir, relativeDir), config, files);
  }

  for (const relativeFile of config.targetFiles) {
    const fullPath = path.join(rootDir, relativeFile);
    if (fs.existsSync(fullPath) && !isExcludedPath(relativeFile, config)) {
      files.push(fullPath);
    }
  }

  return [...new Set(files)];
}

function readUtf8File(filePath) {
  const rawBuffer = fs.readFileSync(filePath);
  return utf8Decoder.decode(rawBuffer);
}

function writeUtf8File(filePath, text) {
  fs.writeFileSync(filePath, String(text || ""), "utf8");
}

function getMojibakeArtifactScore(rawValue = "") {
  const text = String(rawValue || "");
  const artifactMatches = text.match(MOJIBAKE_GLOBAL_REGEX) || [];
  const replacementCount = (text.match(/\uFFFD/g) || []).length;
  return artifactMatches.length + replacementCount;
}

function isWindows1252EncodableCodePoint(codePoint) {
  return codePoint <= 0xff || WINDOWS_1252_CODE_POINT_TO_BYTE.has(codePoint);
}

function encodeWindows1252Text(rawValue = "") {
  const bytes = [];
  for (const ch of String(rawValue || "")) {
    const codePoint = ch.codePointAt(0);
    if (WINDOWS_1252_CODE_POINT_TO_BYTE.has(codePoint)) {
      bytes.push(WINDOWS_1252_CODE_POINT_TO_BYTE.get(codePoint));
      continue;
    }

    if (codePoint <= 0xff) {
      bytes.push(codePoint);
      continue;
    }

    return null;
  }

  return Buffer.from(bytes);
}

function decodeWindows1252BytesAsUtf8(rawValue = "") {
  const encoded = encodeWindows1252Text(rawValue);
  if (!encoded) {
    return String(rawValue || "");
  }

  try {
    return utf8Decoder.decode(encoded);
  } catch {
    return String(rawValue || "");
  }
}

function repairMojibakeWindows1252Chunk(rawValue = "") {
  const text = String(rawValue || "");
  if (!text || !LIKELY_MOJIBAKE_CHUNK_REGEX.test(text)) {
    return text;
  }

  let best = text;
  let current = text;
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const next = decodeWindows1252BytesAsUtf8(current);
    if (!next || next === current) {
      break;
    }

    const bestScore = getMojibakeArtifactScore(best);
    const nextScore = getMojibakeArtifactScore(next);
    if (nextScore < bestScore || (nextScore === bestScore && next.length >= best.length)) {
      best = next;
    }

    current = next;
    if (!LIKELY_MOJIBAKE_CHUNK_REGEX.test(current)) {
      break;
    }
  }

  return best;
}

function repairMojibakeText(rawValue = "") {
  const text = String(rawValue || "");
  if (!text || !LIKELY_MOJIBAKE_CHUNK_REGEX.test(text)) {
    return text;
  }

  let repaired = "";
  let chunk = "";
  for (const ch of text) {
    const codePoint = ch.codePointAt(0);
    if (isWindows1252EncodableCodePoint(codePoint)) {
      chunk += ch;
      continue;
    }

    repaired += repairMojibakeWindows1252Chunk(chunk) + ch;
    chunk = "";
  }

  repaired += repairMojibakeWindows1252Chunk(chunk);
  return repaired;
}

function repairResidualUtf8Pairs(rawValue = "") {
  let next = String(rawValue || "");
  for (const [broken, fixed] of RESIDUAL_UTF8_PAIR_REPLACEMENTS.entries()) {
    if (!next.includes(broken)) {
      continue;
    }
    next = next.split(broken).join(fixed);
  }
  return next;
}

function repairKnownMojibakePhrases(rawValue = "") {
  let next = String(rawValue || "");
  for (const [broken, fixed] of [
    ...KNOWN_MOJIBAKE_REPLACEMENTS.entries(),
    ...ESCAPED_MOJIBAKE_REPLACEMENTS.entries(),
  ]) {
    if (!next.includes(broken)) {
      continue;
    }
    next = next.split(broken).join(fixed);
  }
  return next;
}

function pickBestCandidate(candidates) {
  return [...candidates]
    .map((value, index) => ({
      index,
      value,
      score: getMojibakeArtifactScore(value),
    }))
    .sort((a, b) => a.score - b.score || b.value.length - a.value.length || a.index - b.index)[0]?.value;
}

function repairTextSegment(rawValue = "") {
  const original = String(rawValue || "");
  const candidates = [original];
  let current = original;
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const repairedKnownPhrases = repairKnownMojibakePhrases(current);
    const repaired = repairMojibakeText(repairedKnownPhrases);
    const repairedResidual = repairResidualUtf8Pairs(repaired);
    const next = pickBestCandidate([repairedKnownPhrases, repaired, repairedResidual]) || current;
    candidates.push(repairedKnownPhrases, repaired, repairedResidual, next);
    if (next === current) {
      break;
    }
    current = next;
  }

  return pickBestCandidate(candidates) || original;
}

function repairDocumentText(rawValue = "") {
  const original = String(rawValue || "");
  return original
    .split(/(\r?\n)/g)
    .map((segment) => (/^\r?\n$/.test(segment) ? segment : repairTextSegment(segment)))
    .join("");
}

function countArtifactLines(rawValue = "") {
  return String(rawValue || "")
    .split(/\r?\n/g)
    .filter((line) => MOJIBAKE_REGEX.test(line))
    .length;
}

function getFirstArtifactExample(rawValue = "") {
  const text = String(rawValue || "");
  return text.match(MOJIBAKE_REGEX)?.[0] || "";
}

function validateTextContent(filePath, rawValue = "") {
  const text = String(rawValue || "");
  const extension = path.extname(filePath).toLowerCase();

  try {
    if (extension === ".js" || extension === ".cjs" || extension === ".mjs") {
      new vm.Script(text, { filename: filePath });
    } else if (extension === ".json") {
      JSON.parse(text);
    }
  } catch (error) {
    return {
      ok: false,
      reason: error?.message || String(error),
    };
  }

  return { ok: true, reason: "" };
}

function runTextIntegrityAutoFix(rootDir = process.cwd(), overrides = {}) {
  const changed = [];
  const failures = [];
  const targetFiles = buildTargetFileList(rootDir, overrides);

  for (const filePath of targetFiles) {
    const analysis = analyzeTextFile(filePath);
    const relativePath = path.relative(rootDir, filePath);

    if (analysis.ok) {
      continue;
    }

    if (!analysis.canAutoFix) {
      failures.push({
        filePath: relativePath,
        reason: analysis.validation?.reason || "arquivo ainda precisa de revisao manual",
      });
      continue;
    }

    writeUtf8File(filePath, analysis.repaired);
    const recheck = analyzeTextFile(filePath);
    if (!recheck.ok) {
      writeUtf8File(filePath, analysis.original);
      failures.push({
        filePath: relativePath,
        reason: `o reparo nao ficou limpo (${recheck.lineCountBefore} linha(s) suspeita(s) restantes)`,
      });
      continue;
    }

    changed.push({
      filePath: relativePath,
      before: analysis.lineCountBefore,
      after: recheck.lineCountBefore,
    });
  }

  return {
    rootDir,
    checkedCount: targetFiles.length,
    changed,
    failures,
  };
}
function analyzeTextFile(filePath) {
  try {
    const original = readUtf8File(filePath);
    const repaired = repairDocumentText(original);
    const scoreBefore = getMojibakeArtifactScore(original);
    const scoreAfter = getMojibakeArtifactScore(repaired);
    const validation = repaired !== original ? validateTextContent(filePath, repaired) : { ok: true, reason: "" };
    const canAutoFix = repaired !== original && scoreAfter < scoreBefore && validation.ok;

    return {
      filePath,
      ok: scoreBefore === 0 && !original.includes("\uFFFD"),
      original,
      repaired,
      scoreBefore,
      scoreAfter,
      lineCountBefore: countArtifactLines(original),
      lineCountAfter: countArtifactLines(repaired),
      example: getFirstArtifactExample(original),
      hasReplacementChar: original.includes("\uFFFD"),
      canAutoFix,
      validation,
    };
  } catch (error) {
    return {
      filePath,
      ok: false,
      original: "",
      repaired: "",
      scoreBefore: 0,
      scoreAfter: 0,
      lineCountBefore: 0,
      lineCountAfter: 0,
      example: "",
      hasReplacementChar: false,
      canAutoFix: false,
      validation: {
        ok: false,
        reason: `nao foi possivel ler: ${error?.message || error}`,
      },
    };
  }
}

module.exports = {
  MOJIBAKE_REGEX,
  analyzeTextFile,
  buildTargetFileList,
  countArtifactLines,
  getDefaultConfig,
  getFirstArtifactExample,
  getMojibakeArtifactScore,
  readUtf8File,
  repairDocumentText,
  repairMojibakeText,
  runTextIntegrityAutoFix,
  validateTextContent,
  writeUtf8File,
};
