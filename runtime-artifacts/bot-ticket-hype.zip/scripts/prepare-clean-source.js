"use strict";

const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");

function readText(relativePath) {
  return fs.readFileSync(path.join(ROOT, relativePath), "utf8");
}

function writeText(relativePath, value) {
  fs.writeFileSync(path.join(ROOT, relativePath), value, "utf8");
}

function sanitizeSourceBranding() {
  const filePath = "src/index.js";
  let source = readText(filePath);
  source = source.replace(
    /const DEFAULT_BOT_APPLICATION_DESCRIPTION = \[[\s\S]*?\]\.join\("\\n"\);/,
    [
      "const DEFAULT_BOT_APPLICATION_DESCRIPTION = [",
      '  "Automatize tickets, vendas e atendimento no seu servidor.",',
      '  "Configure categorias, paineis, pagamentos e logs diretamente pelo bot.",',
      '  "Personalize a identidade do bot para a sua comunidade.",',
      '].join("\\n");',
    ].join("\n")
  );
  writeText(filePath, source);
}

const SENSITIVE_KEY_PATTERN =
  /(^|_|\b)(token|secret|clientid|client_id|clientsecret|client_secret|apikey|api_key|password|senha|passphrase|cert|certificate|pixkey|pix_key|webhooksecret|webhook_secret)(_|$|\b)/i;
const ID_KEY_PATTERN = /(^|_|\b)(guild|channel|role|user|message|application|app|owner|admin).*(id|ids)(_|$|\b)|(^|_|\b)(id|ids)(_|$|\b)/i;
const RUNTIME_COLLECTION_PATTERN =
  /paymentidentity|identityby|alertedids|medcursor|watcher|cache|history|logs|tickets|users|runtime|guildsettings/i;

function isSensitiveString(value) {
  const text = String(value || "").trim();
  if (!text) {
    return false;
  }
  return (
    /^\d{17,20}$/.test(text) ||
    /^Client_(Id|Secret)_/i.test(text) ||
    /discord\.gg\/|hype(?:community)?|\.p12\b|data\/certs/i.test(text)
  );
}

function sanitizeValue(value, key = "") {
  if (Array.isArray(value)) {
    if (ID_KEY_PATTERN.test(key) || RUNTIME_COLLECTION_PATTERN.test(key)) {
      return [];
    }
    return value.map((entry) => sanitizeValue(entry, key));
  }

  if (!value || typeof value !== "object") {
    if (typeof value === "string") {
      if (SENSITIVE_KEY_PATTERN.test(key) || ID_KEY_PATTERN.test(key) || isSensitiveString(value)) {
        return "";
      }
    }
    return value;
  }

  const sanitized = {};
  for (const [childKey, childValue] of Object.entries(value)) {
    if (RUNTIME_COLLECTION_PATTERN.test(childKey)) {
      sanitized[childKey] = Array.isArray(childValue) ? [] : {};
      continue;
    }
    sanitized[childKey] = sanitizeValue(childValue, childKey);
  }
  return sanitized;
}

function sanitizeConfig() {
  const configPath = path.join(ROOT, "config.json");
  const config = JSON.parse(fs.readFileSync(configPath, "utf8"));
  const clean = sanitizeValue(config);

  clean.guildSettings = {};
  clean.pixKey = "";
  clean.logChannelId = "";
  clean.ticketPanelChannelId = "";
  clean.botSetupVoiceChannelId = "";
  clean.botSetupStaffMentionRoleIds = [];
  clean.botSetupNotifyAllowedUsersOnTicketOpen = [];

  if (!clean.ai || typeof clean.ai !== "object") {
    clean.ai = {};
  }
  clean.ai.apiKey = "";

  if (!clean.efi || typeof clean.efi !== "object") {
    clean.efi = {};
  }
  Object.assign(clean.efi, {
    pixKey: "",
    clientId: "",
    clientSecret: "",
    webhookSecret: "",
    webhookPublicUrl: "",
    certPath: "",
    certKeyPath: "",
    certP12Path: "",
    certP12Passphrase: "",
    caPath: "",
    accounts: {},
    paymentIdentityByTxid: {},
    paymentIdentityByE2eId: {},
    medAlertedIds: {},
  });

  if (!clean.squarecloudControl || typeof clean.squarecloudControl !== "object") {
    clean.squarecloudControl = {};
  }
  clean.squarecloudControl.appId = "";
  clean.squarecloudControl.apiToken = "";

  if (!clean.squarecloudLogs || typeof clean.squarecloudLogs !== "object") {
    clean.squarecloudLogs = {};
  }
  clean.squarecloudLogs.channelId = "";

  fs.writeFileSync(configPath, `${JSON.stringify(clean, null, 2)}\n`, "utf8");
}

sanitizeSourceBranding();
sanitizeConfig();
