#!/usr/bin/env node
"use strict";

const path = require("path");
const { analyzeTextFile, buildTargetFileList } = require("./text-integrity");

const ROOT = process.cwd();
const results = buildTargetFileList(ROOT).map((filePath) => analyzeTextFile(filePath));
const failures = results.filter((result) => !result.ok);

if (failures.length) {
  console.error("\n[check:text] Falhou: foram encontrados problemas de codificacao/texto:\n");
  for (const result of failures) {
    const relativePath = path.relative(ROOT, result.filePath);
    const reasons = [];

    if (!result.original && !result.repaired && !result.validation.ok) {
      reasons.push(result.validation.reason || "nao foi possivel analisar o arquivo");
    } else {
      if (result.hasReplacementChar) {
        reasons.push("contem caractere corrompido (U+FFFD)");
      }

      if (result.scoreBefore > 0) {
        const suffix = result.example ? `, exemplo: \"${result.example}\"` : "";
        reasons.push(`contem mojibake (${result.lineCountBefore} linha(s) suspeita(s)${suffix})`);
      }

      if (result.canAutoFix) {
        reasons.push(`correcao automatica disponivel (${result.lineCountBefore} -> ${result.lineCountAfter} linha(s) suspeita(s))`);
      } else if (!result.validation.ok) {
        reasons.push(`tentativa de reparo bloqueada por validacao: ${result.validation.reason}`);
      }
    }

    console.error(`- ${relativePath}: ${reasons.join("; ")}`);
  }

  console.error("\nExecute `npm run fix:text` para aplicar o reparo automatico quando ele estiver disponivel.\n");
  process.exit(1);
}

console.log(`[check:text] OK: ${results.length} arquivo(s) validos em UTF-8 e sem mojibake.`);