const fs = require("node:fs");
const path = require("node:path");

const dataFile = path.join(process.cwd(), "data", "botsetup-permissions.json");

function ensureStore() {
  const dir = path.dirname(dataFile);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify({}, null, 2), "utf8");
  }
}

function readStore() {
  ensureStore();
  try {
    const raw = fs.readFileSync(dataFile, "utf8");
    const parsed = JSON.parse(raw || "{}");
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return {};
    }
    return parsed;
  } catch {
    return {};
  }
}

function writeStore(payload) {
  ensureStore();
  fs.writeFileSync(dataFile, JSON.stringify(payload, null, 2), "utf8");
}

function normalizeGuildId(rawGuildId) {
  const value = String(rawGuildId || "").trim();
  return /^\d{17,20}$/.test(value) ? value : "";
}

function normalizeUserIds(rawUserIds) {
  if (!Array.isArray(rawUserIds)) {
    return [];
  }
  const normalized = rawUserIds
    .map((userId) => String(userId || "").trim())
    .filter((userId) => /^\d+$/.test(userId));
  return [...new Set(normalized)];
}

function getAllowedUserIds(guildId) {
  const normalizedGuildId = normalizeGuildId(guildId);
  if (!normalizedGuildId) {
    return [];
  }

  const store = readStore();
  const guildEntry = store[normalizedGuildId];
  if (!guildEntry || typeof guildEntry !== "object") {
    return [];
  }

  const normalizedUserIds = normalizeUserIds(guildEntry.allowedUserIds);
  if (
    normalizedUserIds.length !== (Array.isArray(guildEntry.allowedUserIds) ? guildEntry.allowedUserIds.length : 0)
  ) {
    guildEntry.allowedUserIds = normalizedUserIds;
    guildEntry.updatedAt = new Date().toISOString();
    store[normalizedGuildId] = guildEntry;
    writeStore(store);
  }

  return normalizedUserIds;
}

function setAllowedUserIds(guildId, userIds) {
  const normalizedGuildId = normalizeGuildId(guildId);
  if (!normalizedGuildId) {
    return [];
  }

  const normalizedUserIds = normalizeUserIds(userIds);
  const store = readStore();
  store[normalizedGuildId] = {
    allowedUserIds: normalizedUserIds,
    updatedAt: new Date().toISOString(),
  };
  writeStore(store);
  return normalizedUserIds;
}

module.exports = {
  getAllowedUserIds,
  setAllowedUserIds,
};
