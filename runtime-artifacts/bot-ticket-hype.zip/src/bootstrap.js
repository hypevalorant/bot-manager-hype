"use strict";

require("dotenv").config();

const path = require("path");
const { runTextIntegrityAutoFix } = require("../scripts/text-integrity");
const { initializePostgresState } = require("./postgres-state");

function isTextAutoFixDisabled() {
  const rawValue = String(process.env.TEXT_AUTOFIX_DISABLED || "").trim().toLowerCase();
  return ["1", "true", "yes", "on"].includes(rawValue);
}

async function applyStartupTextIntegrityGuard() {
  if (isTextAutoFixDisabled()) {
    return;
  }

  try {
    const result = runTextIntegrityAutoFix(path.join(__dirname, ".."));

    if (result.changed.length) {
      console.warn("[bootstrap] Reparo automatico de texto aplicado antes da inicializacao:");
      for (const entry of result.changed) {
        console.warn(`- ${entry.filePath}: ${entry.before} -> ${entry.after} linha(s) suspeita(s)`);
      }
    }

    if (result.failures.length) {
      console.warn("[bootstrap] Alguns arquivos ainda precisam de revisao manual de texto:");
      for (const failure of result.failures) {
        console.warn(`- ${failure.filePath}: ${failure.reason}`);
      }
    }
  } catch (error) {
    console.warn("[bootstrap] Nao foi possivel executar a autocorrecao de texto:", error);
  }
}

async function main() {
  await applyStartupTextIntegrityGuard();
  await initializePostgresState();
  require("./index.js");
}

void main().catch((error) => {
  console.error("[bootstrap] falha ao iniciar o runtime:", error);
  process.exit(1);
});
