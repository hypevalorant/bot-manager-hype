"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { Pool } = require("pg");

const DOCUMENT_DEFINITIONS = [
  { key: "config", relativePath: "config.json" },
  { key: "runtime_config", relativePath: "data/config.runtime.json" },
  { key: "users", relativePath: "data/users.json" },
  { key: "tickets", relativePath: "data/tickets.json" },
  { key: "botsetup_permissions", relativePath: "data/botsetup-permissions.json" },
  { key: "efi_webhook_config", relativePath: "efibank/webhook-config.json" },
];

const FILE_TREE_DEFINITIONS = [
  { relativeDir: "transcripts" },
  { relativeDir: "data/certs" },
];

const DEFAULT_SCHEMA = "bot_runtime";
const DEFAULT_DOCS_TABLE = "legacy_bot_state_documents";
const DEFAULT_FILES_TABLE = "legacy_bot_state_files";

let bootstrapPromise = null;

function readFirstEnvValue(envKeys) {
  for (const envKey of envKeys) {
    const value = String(process.env[envKey] ?? "").trim();
    if (value) {
      return value;
    }
  }
  return "";
}

function normalizeIdentifier(value, fallbackValue) {
  const normalized = String(value ?? "")
    .trim()
    .replace(/[^a-zA-Z0-9_]/g, "");
  return normalized || fallbackValue;
}

function resolveSslMaterial(pathEnvKeys, base64EnvKeys, inlineEnvKeys) {
  const base64Value = readFirstEnvValue(base64EnvKeys);
  if (base64Value) {
    return Buffer.from(base64Value, "base64").toString("utf8");
  }

  const inlineValue = readFirstEnvValue(inlineEnvKeys);
  if (inlineValue) {
    return inlineValue;
  }

  const filePath = readFirstEnvValue(pathEnvKeys);
  if (!filePath) {
    return null;
  }

  const absolutePath = path.resolve(filePath);
  if (!fs.existsSync(absolutePath)) {
    throw new Error(`Arquivo SSL do banco nao encontrado em ${absolutePath}.`);
  }

  return fs.readFileSync(absolutePath, "utf8");
}

function resolvePoolConfig() {
  const databaseUrl = readFirstEnvValue(["BOT_STATE_DATABASE_URL", "DATABASE_URL"]);
  const namespace = readFirstEnvValue(["BOT_STATE_NAMESPACE", "STATE_NAMESPACE"]);
  if (!databaseUrl || !namespace) {
    return null;
  }

  const schema = normalizeIdentifier(
    readFirstEnvValue(["BOT_STATE_DATABASE_SCHEMA", "BOT_STATE_SCHEMA"]),
    DEFAULT_SCHEMA
  );
  const docsTable = normalizeIdentifier(
    readFirstEnvValue(["BOT_STATE_DATABASE_DOCS_TABLE", "BOT_STATE_DOCS_TABLE"]),
    DEFAULT_DOCS_TABLE
  );
  const filesTable = normalizeIdentifier(
    readFirstEnvValue(["BOT_STATE_DATABASE_FILES_TABLE", "BOT_STATE_FILES_TABLE"]),
    DEFAULT_FILES_TABLE
  );

  const ca = resolveSslMaterial(
    ["BOT_STATE_DATABASE_SSL_CA_PATH", "DATABASE_SSL_CA_PATH"],
    ["BOT_STATE_DATABASE_SSL_CA_BASE64", "DATABASE_SSL_CA_BASE64"],
    ["BOT_STATE_DATABASE_SSL_CA", "DATABASE_SSL_CA"]
  );
  const cert = resolveSslMaterial(
    ["BOT_STATE_DATABASE_SSL_CERT_PATH", "DATABASE_SSL_CERT_PATH"],
    ["BOT_STATE_DATABASE_SSL_CERT_BASE64", "DATABASE_SSL_CERT_BASE64"],
    ["BOT_STATE_DATABASE_SSL_CERT", "DATABASE_SSL_CERT"]
  );
  const key = resolveSslMaterial(
    ["BOT_STATE_DATABASE_SSL_KEY_PATH", "DATABASE_SSL_KEY_PATH"],
    ["BOT_STATE_DATABASE_SSL_KEY_BASE64", "DATABASE_SSL_KEY_BASE64"],
    ["BOT_STATE_DATABASE_SSL_KEY", "DATABASE_SSL_KEY"]
  );
  const hasTlsMaterial = Boolean(ca || cert || key);
  const sslMode = readFirstEnvValue(["BOT_STATE_DATABASE_SSL", "DATABASE_SSL"]).toLowerCase();
  const rejectUnauthorized =
    readFirstEnvValue([
      "BOT_STATE_DATABASE_SSL_REJECT_UNAUTHORIZED",
      "DATABASE_SSL_REJECT_UNAUTHORIZED",
    ]).toLowerCase() !== "false";

  const ssl =
    !hasTlsMaterial && (!sslMode || ["false", "0", "disable"].includes(sslMode))
      ? undefined
      : {
          rejectUnauthorized: hasTlsMaterial ? rejectUnauthorized : false,
          ...(ca ? { ca } : {}),
          ...(cert ? { cert } : {}),
          ...(key ? { key } : {}),
        };

  return {
    namespace,
    schema,
    docsTable,
    filesTable,
    docsTableRef: `${schema}.${docsTable}`,
    filesTableRef: `${schema}.${filesTable}`,
    pool: new Pool({
      connectionString: databaseUrl,
      ssl,
      max: Number(readFirstEnvValue(["BOT_STATE_DATABASE_POOL_MAX"]) || 2),
      idleTimeoutMillis: Number(readFirstEnvValue(["BOT_STATE_DATABASE_IDLE_TIMEOUT_MS"]) || 30_000),
      connectionTimeoutMillis: Number(
        readFirstEnvValue(["BOT_STATE_DATABASE_CONNECT_TIMEOUT_MS"]) || 15_000
      ),
    }),
  };
}

function ensureParentDir(absolutePath) {
  fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
}

function safeParseJsonFile(absolutePath) {
  try {
    return JSON.parse(fs.readFileSync(absolutePath, "utf8"));
  } catch {
    return {};
  }
}

function collectTrackedFiles(rootDir) {
  const collected = [];
  for (const definition of FILE_TREE_DEFINITIONS) {
    const absoluteDir = path.join(rootDir, definition.relativeDir);
    if (!fs.existsSync(absoluteDir)) {
      continue;
    }
    const stack = [absoluteDir];
    while (stack.length > 0) {
      const current = stack.pop();
      if (!current) {
        continue;
      }
      for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
        const absolutePath = path.join(current, entry.name);
        if (entry.isDirectory()) {
          stack.push(absolutePath);
          continue;
        }
        collected.push({
          absolutePath,
          relativePath: path.relative(rootDir, absolutePath).replaceAll("\\", "/"),
        });
      }
    }
  }
  collected.sort((left, right) => left.relativePath.localeCompare(right.relativePath));
  return collected;
}

function createState(config) {
  return {
    ...config,
    rootDir: process.cwd(),
    hydrating: false,
    queue: Promise.resolve(),
    installed: false,
    originals: {
      writeFileSync: fs.writeFileSync.bind(fs),
      unlinkSync: fs.unlinkSync.bind(fs),
      rmSync: typeof fs.rmSync === "function" ? fs.rmSync.bind(fs) : null,
    },
  };
}

async function ensureStorage(state) {
  await state.pool.query(`create schema if not exists ${state.schema}`);
  await state.pool.query(`
    create table if not exists ${state.docsTableRef} (
      namespace text not null,
      doc_key text not null,
      payload jsonb not null,
      updated_at timestamptz not null default now(),
      primary key (namespace, doc_key)
    )
  `);
  await state.pool.query(`
    create table if not exists ${state.filesTableRef} (
      namespace text not null,
      file_key text not null,
      content bytea not null,
      sha256 text not null,
      updated_at timestamptz not null default now(),
      primary key (namespace, file_key)
    )
  `);
}

async function fetchRemoteState(state) {
  const [docsResult, filesResult] = await Promise.all([
    state.pool.query(
      `select doc_key, payload from ${state.docsTableRef} where namespace = $1 order by doc_key asc`,
      [state.namespace]
    ),
    state.pool.query(
      `select file_key, content from ${state.filesTableRef} where namespace = $1 order by file_key asc`,
      [state.namespace]
    ),
  ]);

  return {
    docs: new Map(
      docsResult.rows.map((row) => [String(row.doc_key || "").trim(), row.payload ?? {}])
    ),
    files: new Map(
      filesResult.rows.map((row) => [String(row.file_key || "").trim(), row.content])
    ),
  };
}

async function upsertDocument(state, docKey, payload) {
  await state.pool.query(
    `
      insert into ${state.docsTableRef} (namespace, doc_key, payload, updated_at)
      values ($1, $2, $3::jsonb, now())
      on conflict (namespace, doc_key)
      do update set payload = excluded.payload, updated_at = excluded.updated_at
    `,
    [state.namespace, docKey, JSON.stringify(payload ?? {})]
  );
}

async function deleteDocument(state, docKey) {
  await state.pool.query(`delete from ${state.docsTableRef} where namespace = $1 and doc_key = $2`, [
    state.namespace,
    docKey,
  ]);
}

async function upsertFile(state, fileKey, content) {
  await state.pool.query(
    `
      insert into ${state.filesTableRef} (namespace, file_key, content, sha256, updated_at)
      values ($1, $2, $3, $4, now())
      on conflict (namespace, file_key)
      do update set content = excluded.content, sha256 = excluded.sha256, updated_at = excluded.updated_at
    `,
    [state.namespace, fileKey, content, crypto.createHash("sha256").update(content).digest("hex")]
  );
}

async function deleteFile(state, fileKey) {
  await state.pool.query(`delete from ${state.filesTableRef} where namespace = $1 and file_key = $2`, [
    state.namespace,
    fileKey,
  ]);
}

async function hydrateState(state) {
  state.hydrating = true;
  try {
    await ensureStorage(state);
    const remote = await fetchRemoteState(state);
    let restoredDocuments = 0;
    let restoredFiles = 0;
    let seededDocuments = 0;
    let seededFiles = 0;

    for (const definition of DOCUMENT_DEFINITIONS) {
      const absolutePath = path.join(state.rootDir, definition.relativePath);
      if (remote.docs.has(definition.key)) {
        ensureParentDir(absolutePath);
        state.originals.writeFileSync(
          absolutePath,
          `${JSON.stringify(remote.docs.get(definition.key) ?? {}, null, 2)}\n`,
          "utf8"
        );
        restoredDocuments += 1;
        continue;
      }

      if (fs.existsSync(absolutePath)) {
        await upsertDocument(state, definition.key, safeParseJsonFile(absolutePath));
        seededDocuments += 1;
      }
    }

    for (const [fileKey, content] of remote.files.entries()) {
      if (!fileKey) {
        continue;
      }
      const absolutePath = path.join(state.rootDir, ...fileKey.split("/"));
      ensureParentDir(absolutePath);
      state.originals.writeFileSync(absolutePath, content);
      restoredFiles += 1;
    }

    const remoteFileKeys = new Set(remote.files.keys());
    for (const fileEntry of collectTrackedFiles(state.rootDir)) {
      if (remoteFileKeys.has(fileEntry.relativePath)) {
        continue;
      }
      await upsertFile(state, fileEntry.relativePath, fs.readFileSync(fileEntry.absolutePath));
      seededFiles += 1;
    }

    return {
      restoredDocuments,
      restoredFiles,
      seededDocuments,
      seededFiles,
    };
  } finally {
    state.hydrating = false;
  }
}

function resolveAbsolutePath(targetPath) {
  if (typeof targetPath !== "string" || !targetPath.trim()) {
    return null;
  }
  return path.resolve(targetPath);
}

function getTrackedDocumentByAbsolutePath(rootDir, absolutePath) {
  const normalizedTarget = absolutePath.replaceAll("\\", "/");
  return (
    DOCUMENT_DEFINITIONS.find((definition) => {
      const trackedPath = path.join(rootDir, definition.relativePath).replaceAll("\\", "/");
      return trackedPath === normalizedTarget;
    }) ?? null
  );
}

function getTrackedRelativeFilePath(rootDir, absolutePath) {
  const relativePath = path.relative(rootDir, absolutePath).replaceAll("\\", "/");
  if (!relativePath || relativePath.startsWith("..")) {
    return null;
  }
  for (const definition of FILE_TREE_DEFINITIONS) {
    if (relativePath === definition.relativeDir || relativePath.startsWith(`${definition.relativeDir}/`)) {
      return relativePath;
    }
  }
  return null;
}

function queueMirror(state, action, absolutePath) {
  const trackedDocument = getTrackedDocumentByAbsolutePath(state.rootDir, absolutePath);
  const trackedFile = getTrackedRelativeFilePath(state.rootDir, absolutePath);
  if (!trackedDocument && !trackedFile) {
    return;
  }

  state.queue = state.queue
    .then(async () => {
      if (trackedDocument) {
        if (action === "delete" || !fs.existsSync(absolutePath)) {
          await deleteDocument(state, trackedDocument.key);
          return;
        }
        await upsertDocument(state, trackedDocument.key, safeParseJsonFile(absolutePath));
        return;
      }

      if (!trackedFile) {
        return;
      }
      if (action === "delete" || !fs.existsSync(absolutePath)) {
        await deleteFile(state, trackedFile);
        return;
      }
      await upsertFile(state, trackedFile, fs.readFileSync(absolutePath));
    })
    .catch((error) => {
      console.error("[postgres-state] falha ao sincronizar com o PostgreSQL:", error);
    });
}

function installFsMirrors(state) {
  if (state.installed) {
    return;
  }

  fs.writeFileSync = function patchedWriteFileSync(targetPath, data, options) {
    const result = state.originals.writeFileSync(targetPath, data, options);
    if (!state.hydrating) {
      const absolutePath = resolveAbsolutePath(targetPath);
      if (absolutePath) {
        queueMirror(state, "write", absolutePath);
      }
    }
    return result;
  };

  fs.unlinkSync = function patchedUnlinkSync(targetPath) {
    const absolutePath = resolveAbsolutePath(targetPath);
    const result = state.originals.unlinkSync(targetPath);
    if (!state.hydrating && absolutePath) {
      queueMirror(state, "delete", absolutePath);
    }
    return result;
  };

  if (state.originals.rmSync) {
    fs.rmSync = function patchedRmSync(targetPath, options) {
      const absolutePath = resolveAbsolutePath(targetPath);
      const trackedFile = absolutePath ? getTrackedRelativeFilePath(state.rootDir, absolutePath) : null;
      const trackedDocument =
        absolutePath ? getTrackedDocumentByAbsolutePath(state.rootDir, absolutePath) : null;
      const result = state.originals.rmSync(targetPath, options);

      if (!state.hydrating && absolutePath && (trackedFile || trackedDocument)) {
        if (trackedDocument) {
          queueMirror(state, "delete", absolutePath);
        } else if (trackedFile) {
          if (fs.existsSync(absolutePath) && fs.statSync(absolutePath).isDirectory()) {
            return result;
          }
          queueMirror(state, "delete", absolutePath);
        }
      }

      return result;
    };
  }

  process.on("beforeExit", () => state.queue);
  process.on("SIGTERM", () => {
    state.queue.catch(() => undefined);
  });
  process.on("SIGINT", () => {
    state.queue.catch(() => undefined);
  });

  state.installed = true;
}

async function initializePostgresState() {
  if (!bootstrapPromise) {
    bootstrapPromise = (async () => {
      const poolConfig = resolvePoolConfig();
      if (!poolConfig) {
        return { enabled: false };
      }

      const state = createState(poolConfig);
      const summary = await hydrateState(state);
      installFsMirrors(state);

      console.log(
        `[postgres-state] sincronizacao ativa namespace=${state.namespace} schema=${state.schema} restored_docs=${summary.restoredDocuments} restored_files=${summary.restoredFiles} seeded_docs=${summary.seededDocuments} seeded_files=${summary.seededFiles}`
      );

      return {
        enabled: true,
        state,
        summary,
      };
    })();
  }

  return bootstrapPromise;
}

module.exports = {
  initializePostgresState,
};
