﻿const path = require("node:path");

function isPlaceholderEnvValue(rawValue, placeholderValues = []) {
  const value = String(rawValue || "").trim();
  if (!value) {
    return false;
  }

  if (placeholderValues instanceof Set ? placeholderValues.has(value) : placeholderValues.includes(value)) {
    return true;
  }

  return /^(SEU_|ID_DO_|COLOQUE_)/i.test(value);
}

function isDiscordSnowflake(rawValue) {
  const value = String(rawValue || "").trim();
  return /^\d{17,20}$/.test(value);
}

function resolveEnvPath(rawPath) {
  const value = String(rawPath || "").trim();
  if (!value) {
    return "";
  }
  return path.isAbsolute(value) ? value : path.resolve(process.cwd(), value);
}

function parseBooleanInput(rawValue, fallbackValue) {
  const normalized = String(rawValue || "").trim().toLowerCase();
  if (!normalized) {
    return fallbackValue;
  }
  if (["1", "true", "sim", "yes", "on"].includes(normalized)) {
    return true;
  }
  if (["0", "false", "nao", "no", "off"].includes(normalized)) {
    return false;
  }
  return fallbackValue;
}

function isTicketAiEnabled(rawValue) {
  return parseBooleanInput(rawValue, false) === true;
}

module.exports = {
  isPlaceholderEnvValue,
  isDiscordSnowflake,
  resolveEnvPath,
  parseBooleanInput,
  isTicketAiEnabled,
};
