const fs = require("node:fs");

function isPlainObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function cloneSerializableValue(value) {
  if (value === null || typeof value !== "object") {
    return value;
  }

  if (typeof globalThis.structuredClone === "function") {
    try {
      return globalThis.structuredClone(value);
    } catch {
      // fallback JSON clone abaixo
    }
  }

  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return value;
  }
}


function stripUtf8Bom(rawValue = "") {
  const text = String(rawValue || "");
  return text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
}


const utf8Decoder = new TextDecoder("utf-8", { fatal: true });
const WINDOWS_1252_CODE_POINT_TO_BYTE = new Map([
  [0x20ac, 0x80],
  [0x201a, 0x82],
  [0x0192, 0x83],
  [0x201e, 0x84],
  [0x2026, 0x85],
  [0x2020, 0x86],
  [0x2021, 0x87],
  [0x02c6, 0x88],
  [0x2030, 0x89],
  [0x0160, 0x8a],
  [0x2039, 0x8b],
  [0x0152, 0x8c],
  [0x017d, 0x8e],
  [0x2018, 0x91],
  [0x2019, 0x92],
  [0x201c, 0x93],
  [0x201d, 0x94],
  [0x2022, 0x95],
  [0x2013, 0x96],
  [0x2014, 0x97],
  [0x02dc, 0x98],
  [0x2122, 0x99],
  [0x0161, 0x9a],
  [0x203a, 0x9b],
  [0x0153, 0x9c],
  [0x017e, 0x9e],
  [0x0178, 0x9f],
]);

function getMojibakeArtifactScore(rawValue = "") {
  const text = String(rawValue || "");
  const suspiciousCount = (text.match(/[\u00c3\u00c2\u00e2\u00f0]/g) || []).length;
  const replacementCount = (text.match(/\uFFFD/g) || []).length;
  return suspiciousCount + replacementCount * 2;
}

function isWindows1252EncodableCodePoint(codePoint) {
  return codePoint <= 0xff || WINDOWS_1252_CODE_POINT_TO_BYTE.has(codePoint);
}

function encodeWindows1252Text(rawValue = "") {
  const bytes = [];
  for (const ch of String(rawValue || "")) {
    const codePoint = ch.codePointAt(0);
    if (WINDOWS_1252_CODE_POINT_TO_BYTE.has(codePoint)) {
      bytes.push(WINDOWS_1252_CODE_POINT_TO_BYTE.get(codePoint));
      continue;
    }
    if (codePoint <= 0xff) {
      bytes.push(codePoint);
      continue;
    }
    return null;
  }
  return Buffer.from(bytes);
}

function decodeWindows1252BytesAsUtf8(rawValue = "") {
  const encoded = encodeWindows1252Text(rawValue);
  if (!encoded) {
    return String(rawValue || "");
  }
  try {
    return utf8Decoder.decode(encoded);
  } catch {
    return String(rawValue || "");
  }
}

function repairMojibakeWindows1252Chunk(rawValue = "") {
  const text = String(rawValue || "");
  if (!text || !/[\u00c3\u00c2\u00e2\u00f0]/.test(text)) {
    return text;
  }

  let best = text;
  let current = text;
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const next = decodeWindows1252BytesAsUtf8(current);
    if (!next || next === current) {
      break;
    }
    const bestScore = getMojibakeArtifactScore(best);
    const nextScore = getMojibakeArtifactScore(next);
    if (nextScore < bestScore || (nextScore === bestScore && next.length >= best.length)) {
      best = next;
    }
    current = next;
    if (!/[\u00c3\u00c2\u00e2\u00f0]/.test(current)) {
      break;
    }
  }

  return best;
}

function repairMojibakeText(rawValue = "") {
  const text = String(rawValue || "");
  if (!text || !/[\u00c3\u00c2\u00e2\u00f0]/.test(text)) {
    return text;
  }

  let repaired = "";
  let chunk = "";
  for (const ch of text) {
    const codePoint = ch.codePointAt(0);
    if (isWindows1252EncodableCodePoint(codePoint)) {
      chunk += ch;
      continue;
    }
    repaired += repairMojibakeWindows1252Chunk(chunk) + ch;
    chunk = "";
  }
  repaired += repairMojibakeWindows1252Chunk(chunk);
  return repaired;
}

function repairMojibakeInSerializableValue(rawValue) {
  if (typeof rawValue === "string") {
    return repairMojibakeText(rawValue);
  }
  if (Array.isArray(rawValue)) {
    return rawValue.map((entry) => repairMojibakeInSerializableValue(entry));
  }
  if (!rawValue || typeof rawValue !== "object") {
    return rawValue;
  }

  const repaired = {};
  for (const [key, value] of Object.entries(rawValue)) {
    const repairedKey = repairMojibakeText(key);
    repaired[repairedKey] = repairMojibakeInSerializableValue(value);
  }
  return repaired;
}

function readJsonObjectSafe(filePath) {
  try {
    const raw = stripUtf8Bom(fs.readFileSync(filePath, "utf8"));
    const parsed = JSON.parse(raw || "{}");
    return isPlainObject(parsed) ? repairMojibakeInSerializableValue(parsed) : {};
  } catch {
    return {};
  }
}

function deepMergeConfig(baseValue, overrideValue) {
  if (Array.isArray(baseValue) && Array.isArray(overrideValue)) {
    return cloneSerializableValue(overrideValue);
  }

  if (isPlainObject(baseValue) && isPlainObject(overrideValue)) {
    const merged = { ...cloneSerializableValue(baseValue) };
    for (const [key, value] of Object.entries(overrideValue)) {
      merged[key] = deepMergeConfig(baseValue[key], value);
    }
    return merged;
  }

  if (typeof overrideValue !== "undefined") {
    return cloneSerializableValue(overrideValue);
  }

  return cloneSerializableValue(baseValue);
}

module.exports = {
  isPlainObject,
  cloneSerializableValue,
  stripUtf8Bom,
  readJsonObjectSafe,
  deepMergeConfig,
  repairMojibakeText,
  repairMojibakeInSerializableValue,
};
