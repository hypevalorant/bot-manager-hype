const OPENAI_CHAT_COMPLETIONS_URL = "https://api.openai.com/v1/chat/completions";
const GROQ_CHAT_COMPLETIONS_URL = "https://api.groq.com/openai/v1/chat/completions";

function resolveChatCompletionsUrl({ apiKey, baseUrl }) {
  const explicitUrl = String(baseUrl || process.env.AI_CHAT_COMPLETIONS_URL || "").trim();
  if (explicitUrl) {
    return explicitUrl;
  }

  const key = String(apiKey || "").trim();
  if (/^gsk_/i.test(key)) {
    return GROQ_CHAT_COMPLETIONS_URL;
  }

  return OPENAI_CHAT_COMPLETIONS_URL;
}

async function postChatCompletions(payload, { apiKey, baseUrl }) {
  const targetUrl = resolveChatCompletionsUrl({ apiKey, baseUrl });
  const timeoutMs = Math.max(5000, Number(process.env.AI_HTTP_TIMEOUT_MS || 25000));
  const controller = new AbortController();
  const timeoutHandle = setTimeout(() => controller.abort(), timeoutMs);
  let response;
  try {
    response = await fetch(targetUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
  } catch (error) {
    const errText =
      error?.name === "AbortError"
        ? `request_timeout (${timeoutMs}ms)`
        : String(error?.message || error || "unknown_fetch_error");
    return { ok: false, status: 0, errText, data: null };
  } finally {
    clearTimeout(timeoutHandle);
  }

  if (!response.ok) {
    const errText = await response.text();
    return { ok: false, status: response.status, errText, data: null };
  }

  const data = await response.json();
  return { ok: true, status: response.status, errText: "", data };
}

async function requestOpenAIChatCompletions({
  apiKey,
  model,
  messages,
  temperature = 0.4,
  maxTokens = 450,
  responseFormat = null,
  baseUrl = "",
}) {
  if (!apiKey) {
    return null;
  }

  const payload = {
    model,
    temperature,
    messages,
    max_tokens: maxTokens,
  };
  if (responseFormat && typeof responseFormat === "object") {
    payload.response_format = responseFormat;
  }

  const firstAttempt = await postChatCompletions(payload, { apiKey, baseUrl });
  if (firstAttempt.ok) {
    return firstAttempt.data;
  }

  const responseFormatMayBeUnsupported =
    Boolean(responseFormat && typeof responseFormat === "object") &&
    firstAttempt.status === 400 &&
    /response_format|json_object|unsupported|not supported/i.test(firstAttempt.errText || "");
  if (responseFormatMayBeUnsupported) {
    const fallbackPayload = { ...payload };
    delete fallbackPayload.response_format;
    const retryAttempt = await postChatCompletions(fallbackPayload, { apiKey, baseUrl });
    if (retryAttempt.ok) {
      return retryAttempt.data;
    }
    throw new Error(`OpenAI-compatible error: ${retryAttempt.status} ${retryAttempt.errText}`);
  }

  throw new Error(`OpenAI-compatible error: ${firstAttempt.status} ${firstAttempt.errText}`);
}

function parseJsonObjectFromText(rawValue) {
  const text = String(rawValue || "").trim();
  if (!text) {
    return null;
  }

  try {
    return JSON.parse(text);
  } catch {
    // fallback quando o modelo retorna texto antes/depois do JSON.
  }

  const firstCurly = text.indexOf("{");
  const lastCurly = text.lastIndexOf("}");
  if (firstCurly >= 0 && lastCurly > firstCurly) {
    const candidate = text.slice(firstCurly, lastCurly + 1);
    try {
      return JSON.parse(candidate);
    } catch {
      return null;
    }
  }

  return null;
}

async function analyzePaymentReceiptImage({ apiKey, model, imageUrl }) {
  if (!apiKey || !imageUrl) {
    return null;
  }

  const response = await requestOpenAIChatCompletions({
    apiKey,
    model: model || "gpt-4o-mini",
    temperature: 0,
    maxTokens: 500,
    responseFormat: { type: "json_object" },
    messages: [
      {
        role: "system",
        content:
          "Voce analisa comprovantes PIX. Responda somente JSON. " +
          "Campos obrigatorios: is_receipt (bool), is_likely_authentic (bool), confidence (0..1), " +
          "amount_brl (number|null), e2e_id (string|null), txid (string|null), bank (string|null), " +
          "payer_name (string|null), recipient_name (string|null), reason (string).",
      },
      {
        role: "user",
        content: [
          {
            type: "text",
            text:
              "Verifique se a imagem e um comprovante de pagamento PIX real (sem sinais claros de edicao). " +
              "Extraia os dados legiveis. Se nao conseguir, mantenha null e explique em reason.",
          },
          {
            type: "image_url",
            image_url: {
              url: String(imageUrl),
            },
          },
        ],
      },
    ],
  });

  const rawContent = response?.choices?.[0]?.message?.content || "";
  const parsed = parseJsonObjectFromText(rawContent);
  if (!parsed || typeof parsed !== "object") {
    return null;
  }

  const confidenceRaw = Number(parsed.confidence);
  const confidence = Number.isFinite(confidenceRaw)
    ? Math.max(0, Math.min(1, confidenceRaw))
    : 0;
  const amountRaw = Number(parsed.amount_brl);

  return {
    isReceipt: Boolean(parsed.is_receipt),
    isLikelyAuthentic: Boolean(parsed.is_likely_authentic),
    confidence,
    amountBrl: Number.isFinite(amountRaw) ? amountRaw : null,
    e2eId: parsed.e2e_id ? String(parsed.e2e_id).trim() : "",
    txid: parsed.txid ? String(parsed.txid).trim() : "",
    bank: parsed.bank ? String(parsed.bank).trim() : "",
    payerName: parsed.payer_name ? String(parsed.payer_name).trim() : "",
    recipientName: parsed.recipient_name ? String(parsed.recipient_name).trim() : "",
    reason: parsed.reason ? String(parsed.reason).trim() : "",
  };
}

async function generateAIReply({
  apiKey,
  model,
  systemPrompt,
  messages,
  temperature = 0.25,
  maxTokens = 220,
}) {
  if (!apiKey) {
    return null;
  }

  const data = await requestOpenAIChatCompletions({
    apiKey,
    model,
    temperature,
    maxTokens,
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      ...messages,
    ],
  });

  return data?.choices?.[0]?.message?.content?.trim() || null;
}

module.exports = { generateAIReply, analyzePaymentReceiptImage };
