const fs = require("node:fs");
const path = require("node:path");

const dataFile = path.join(process.cwd(), "data", "tickets.json");

function ensureStore() {
  const dir = path.dirname(dataFile);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify({}, null, 2), "utf8");
  }
}

function readStore() {
  ensureStore();
  try {
    const raw = fs.readFileSync(dataFile, "utf8");
    return JSON.parse(raw || "{}");
  } catch {
    return {};
  }
}

function writeStore(payload) {
  ensureStore();
  fs.writeFileSync(dataFile, JSON.stringify(payload, null, 2), "utf8");
}

function getTicket(channelId) {
  const store = readStore();
  return store[channelId] || null;
}

function setTicket(channelId, data) {
  const store = readStore();
  store[channelId] = data;
  writeStore(store);
}

function removeTicket(channelId) {
  const store = readStore();
  delete store[channelId];
  writeStore(store);
}

function getAllTickets() {
  return readStore();
}

module.exports = {
  getTicket,
  setTicket,
  removeTicket,
  getAllTickets,
};
