const fs = require("node:fs");
const path = require("node:path");

const dataFile = path.join(process.cwd(), "data", "users.json");

function ensureStore() {
  const dir = path.dirname(dataFile);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify({}, null, 2), "utf8");
  }
}

function readStore() {
  ensureStore();
  try {
    const raw = fs.readFileSync(dataFile, "utf8");
    return JSON.parse(raw || "{}");
  } catch {
    return {};
  }
}

function writeStore(payload) {
  ensureStore();
  fs.writeFileSync(dataFile, JSON.stringify(payload, null, 2), "utf8");
}

function ensureUser(userId) {
  const store = readStore();
  if (!store[userId]) {
    store[userId] = {
      ticketsOpened: 0,
      ticketsClosed: 0,
      aiInteractions: 0,
      points: 0,
      updatedAt: new Date().toISOString(),
    };
    writeStore(store);
  }
  return store[userId];
}

function getUser(userId) {
  return ensureUser(userId);
}

function bumpUser(userId, changes = {}) {
  const store = readStore();
  if (!store[userId]) {
    store[userId] = {
      ticketsOpened: 0,
      ticketsClosed: 0,
      aiInteractions: 0,
      points: 0,
      updatedAt: new Date().toISOString(),
    };
  }

  for (const [key, delta] of Object.entries(changes)) {
    if (typeof delta === "number") {
      store[userId][key] = (store[userId][key] || 0) + delta;
    }
  }

  store[userId].updatedAt = new Date().toISOString();
  writeStore(store);
  return store[userId];
}

function getAllUsers() {
  return readStore();
}

function resetAllUsersStats() {
  writeStore({});
}

module.exports = {
  getUser,
  bumpUser,
  getAllUsers,
  resetAllUsersStats,
};
