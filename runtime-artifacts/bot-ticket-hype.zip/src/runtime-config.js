﻿const fs = require("node:fs");
const path = require("node:path");
const { AsyncLocalStorage } = require("node:async_hooks");

const { cloneSerializableValue, readJsonObjectSafe, deepMergeConfig, repairMojibakeInSerializableValue } = require("./utils/json");

function createRuntimeConfigStore({
  configPath,
  runtimeConfigPath = path.join(process.cwd(), "data", "config.runtime.json"),
  normalizeGuildScopeId,
}) {
  if (!fs.existsSync(configPath)) {
    throw new Error("Arquivo config.json não encontrado na raiz do projeto.");
  }

  const guildConfigScopeStorage = new AsyncLocalStorage();
  const configUnscopedKeys = new Set([
    "guildSettings",
    "payment",
    "efi",
    "squarecloudControl",
    "squarecloudLogs",
    "transcriptViewerPublicUrl",
  ]);

  function ensureRuntimeConfigStore() {
    const dir = path.dirname(runtimeConfigPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  function writeRuntimeConfigSnapshot(payload) {
    ensureRuntimeConfigStore();
    const normalizedPayload = repairMojibakeInSerializableValue(payload);
    fs.writeFileSync(runtimeConfigPath, JSON.stringify(normalizedPayload, null, 2), "utf8");
  }

  function loadConfigSnapshot() {
    const baseConfig = readJsonObjectSafe(configPath);
    const runtimeConfig = readJsonObjectSafe(runtimeConfigPath);
    const mergedConfig = repairMojibakeInSerializableValue(deepMergeConfig(baseConfig, runtimeConfig));
    if (!fs.existsSync(runtimeConfigPath)) {
      writeRuntimeConfigSnapshot(mergedConfig);
    }
    return mergedConfig;
  }

  const configRaw = loadConfigSnapshot();

  function ensureGuildSettingsRootRaw() {
    if (
      !configRaw.guildSettings ||
      typeof configRaw.guildSettings !== "object" ||
      Array.isArray(configRaw.guildSettings)
    ) {
      configRaw.guildSettings = {};
    }
    return configRaw.guildSettings;
  }

  function getActiveConfigScopeGuildId() {
    const store = guildConfigScopeStorage.getStore();
    return normalizeGuildScopeId(store?.guildId || "");
  }

  function isConfigKeyUnscoped(prop) {
    return typeof prop === "string" && configUnscopedKeys.has(prop);
  }

  function getGuildScopedConfigTarget(guildId, { create = false } = {}) {
    const normalizedGuildId = normalizeGuildScopeId(guildId);
    if (!normalizedGuildId) {
      return null;
    }

    const guildSettings = ensureGuildSettingsRootRaw();
    const current = guildSettings[normalizedGuildId];
    if (current && typeof current === "object" && !Array.isArray(current)) {
      return current;
    }
    if (!create) {
      return null;
    }

    guildSettings[normalizedGuildId] = {};
    return guildSettings[normalizedGuildId];
  }

  function withGuildConfigScope(guildId, callback) {
    const normalizedGuildId = normalizeGuildScopeId(guildId);
    if (!normalizedGuildId) {
      return callback();
    }
    return guildConfigScopeStorage.run({ guildId: normalizedGuildId }, callback);
  }

  const config = new Proxy(configRaw, {
    get(target, prop) {
      if (typeof prop !== "string" || isConfigKeyUnscoped(prop)) {
        return Reflect.get(target, prop);
      }

      const scopedGuildId = getActiveConfigScopeGuildId();
      if (!scopedGuildId) {
        return Reflect.get(target, prop);
      }

      const scopedTarget = getGuildScopedConfigTarget(scopedGuildId, { create: true });
      if (scopedTarget && Object.prototype.hasOwnProperty.call(scopedTarget, prop)) {
        return scopedTarget[prop];
      }

      if (Object.prototype.hasOwnProperty.call(target, prop)) {
        const clonedValue = cloneSerializableValue(target[prop]);
        if (scopedTarget) {
          scopedTarget[prop] = clonedValue;
        }
        return clonedValue;
      }

      return undefined;
    },
    set(target, prop, value) {
      if (typeof prop !== "string" || isConfigKeyUnscoped(prop)) {
        return Reflect.set(target, prop, value);
      }

      const scopedGuildId = getActiveConfigScopeGuildId();
      if (!scopedGuildId) {
        return Reflect.set(target, prop, value);
      }

      const scopedTarget = getGuildScopedConfigTarget(scopedGuildId, { create: true });
      if (!scopedTarget) {
        return Reflect.set(target, prop, value);
      }
      scopedTarget[prop] = value;
      return true;
    },
    deleteProperty(target, prop) {
      if (typeof prop !== "string" || isConfigKeyUnscoped(prop)) {
        return Reflect.deleteProperty(target, prop);
      }

      const scopedGuildId = getActiveConfigScopeGuildId();
      if (!scopedGuildId) {
        return Reflect.deleteProperty(target, prop);
      }

      const scopedTarget = getGuildScopedConfigTarget(scopedGuildId, { create: false });
      if (!scopedTarget) {
        return true;
      }
      return Reflect.deleteProperty(scopedTarget, prop);
    },
    has(target, prop) {
      if (typeof prop !== "string" || isConfigKeyUnscoped(prop)) {
        return Reflect.has(target, prop);
      }

      const scopedGuildId = getActiveConfigScopeGuildId();
      if (!scopedGuildId) {
        return Reflect.has(target, prop);
      }

      const scopedTarget = getGuildScopedConfigTarget(scopedGuildId, { create: false });
      if (scopedTarget && Reflect.has(scopedTarget, prop)) {
        return true;
      }
      return Reflect.has(target, prop);
    },
    ownKeys(target) {
      const scopedGuildId = getActiveConfigScopeGuildId();
      if (!scopedGuildId) {
        return Reflect.ownKeys(target);
      }

      const scopedTarget = getGuildScopedConfigTarget(scopedGuildId, { create: false });
      if (!scopedTarget) {
        return Reflect.ownKeys(target);
      }

      return [...new Set([...Reflect.ownKeys(target), ...Reflect.ownKeys(scopedTarget)])];
    },
    getOwnPropertyDescriptor(target, prop) {
      if (typeof prop !== "string" || isConfigKeyUnscoped(prop)) {
        return Reflect.getOwnPropertyDescriptor(target, prop);
      }

      const scopedGuildId = getActiveConfigScopeGuildId();
      if (!scopedGuildId) {
        return Reflect.getOwnPropertyDescriptor(target, prop);
      }

      const scopedTarget = getGuildScopedConfigTarget(scopedGuildId, { create: false });
      if (scopedTarget && Object.prototype.hasOwnProperty.call(scopedTarget, prop)) {
        return Object.getOwnPropertyDescriptor(scopedTarget, prop);
      }
      return Reflect.getOwnPropertyDescriptor(target, prop);
    },
    defineProperty(target, prop, descriptor) {
      if (typeof prop !== "string" || isConfigKeyUnscoped(prop)) {
        return Reflect.defineProperty(target, prop, descriptor);
      }

      const scopedGuildId = getActiveConfigScopeGuildId();
      if (!scopedGuildId) {
        return Reflect.defineProperty(target, prop, descriptor);
      }

      const scopedTarget = getGuildScopedConfigTarget(scopedGuildId, { create: true });
      if (!scopedTarget) {
        return Reflect.defineProperty(target, prop, descriptor);
      }
      return Reflect.defineProperty(scopedTarget, prop, descriptor);
    },
  });

  return {
    config,
    configRaw,
    writeRuntimeConfigSnapshot,
    withGuildConfigScope,
    getActiveConfigScopeGuildId,
  };
}

module.exports = { createRuntimeConfigStore };
