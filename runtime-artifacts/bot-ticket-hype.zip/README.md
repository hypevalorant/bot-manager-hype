# Bot Ticket Hype

Source limpa para hospedagem de um bot Discord de tickets, vendas, Pix/EFI, transcripts, bot setup e integracoes opcionais com IA e Square Cloud.

## Requisitos

- Node.js 20 ou superior
- Um bot no Discord Developer Portal
- Permissoes de slash commands no servidor

## Instalacao

```bash
npm install
copy .env.example .env
npm start
```

Preencha no `.env` pelo menos:

- `TOKEN`: token do bot Discord
- `CLIENT_ID`: ID da aplicacao Discord
- `GUILD_ID`: opcional, registra comandos em um servidor especifico

## Arquivos que nao devem ser publicados

O repositorio ignora automaticamente dados de runtime e segredos:

- `.env`
- `data/`
- `transcripts/`
- `deploy/`
- certificados `.p12`, `.pem`, `.key`
- `node_modules/`
- backups locais

## Configuracao

O arquivo `config.json` vem sanitizado e serve como base global. Alteracoes feitas pelo painel do bot sao gravadas em `data/config.runtime.json`, que nao e versionado.

Para Pix/EFI, configure as variaveis `EFI_*` no ambiente ou use o painel do bot para cadastrar as contas. Certificados devem ficar fora do Git.
