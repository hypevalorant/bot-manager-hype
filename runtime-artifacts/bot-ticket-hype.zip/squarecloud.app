DISPLAY_NAME=Bot Ticket Hype Runtime
MAIN=manager-runtime.js
MEMORY=256
VERSION=recommended
AUTORESTART=true
DESCRIPTION=Runtime gerenciado para bot-ticket-hype